CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    CREATE ROLE anon NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
  default_visibility TEXT NOT NULL DEFAULT 'public' CHECK (default_visibility IN ('public', 'private')),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'user')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

CREATE TABLE IF NOT EXISTS public.storage_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL DEFAULT 'local',
  storj_access_key TEXT,
  storj_secret_key TEXT,
  storj_endpoint TEXT DEFAULT 'https://gateway.storjshare.io',
  storj_bucket TEXT,
  max_file_size_mb INTEGER NOT NULL DEFAULT 500,
  allowed_types TEXT[] NOT NULL DEFAULT ARRAY['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo'],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.user_quotas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  storage_used_bytes BIGINT NOT NULL DEFAULT 0,
  storage_limit_bytes BIGINT NOT NULL DEFAULT 536870912,
  upload_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL DEFAULT 'Untitled',
  filename TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  share_id TEXT NOT NULL UNIQUE,
  views INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  size BIGINT,
  visibility TEXT NOT NULL DEFAULT 'public' CHECK (visibility IN ('public', 'private'))
);

CREATE INDEX IF NOT EXISTS idx_videos_user_id ON public.videos (user_id);
CREATE INDEX IF NOT EXISTS idx_videos_share_id ON public.videos (share_id);

-- Composite index to support efficient listing and range queries for a user's videos
CREATE INDEX IF NOT EXISTS idx_videos_user_created_at_desc ON public.videos (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_user_created_at ON public.videos (user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_videos_user_visibility ON public.videos (user_id, visibility);

-- Function to reconcile storage quotas based on actual videos
CREATE OR REPLACE FUNCTION public.reconcile_user_storage()
RETURNS void AS $$
BEGIN
  -- Update each user's storage_used_bytes to match actual video sizes
  UPDATE public.user_quotas uq
  SET storage_used_bytes = COALESCE(
    (SELECT COALESCE(SUM(size), 0) FROM public.videos WHERE user_id = uq.user_id),
    0
  )
  WHERE user_id IN (SELECT DISTINCT user_id FROM public.videos);
  
  -- Also update users with no videos
  UPDATE public.user_quotas
  SET storage_used_bytes = 0
  WHERE user_id NOT IN (SELECT DISTINCT user_id FROM public.videos) 
    AND storage_used_bytes != 0;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

DROP TRIGGER IF EXISTS update_videos_updated_at ON public.videos;
CREATE TRIGGER update_videos_updated_at
BEFORE UPDATE ON public.videos
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_storage_config_updated_at ON public.storage_config;
CREATE TRIGGER update_storage_config_updated_at
BEFORE UPDATE ON public.storage_config
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_user_quotas_updated_at ON public.user_quotas;
CREATE TRIGGER update_user_quotas_updated_at
BEFORE UPDATE ON public.user_quotas
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.storage_config (provider)
SELECT 'local'
WHERE NOT EXISTS (SELECT 1 FROM public.storage_config);
