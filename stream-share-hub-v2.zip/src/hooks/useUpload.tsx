import { useUploadContext } from "../contexts/UploadContext";

export function useUpload() {
  return useUploadContext();
}
